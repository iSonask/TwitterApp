//
//  Service.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 06/05/17.
//
//

import Foundation
import TRON
import SwiftyJSON

struct Service {
    static let sharedInstance = Service()
    
    let tron = TRON(baseURL: "https://api.letsbuildthatapp.com")
    class JSONError: JSONDecodable {
        required init(json: JSON) throws {
            print("JSON ERROR")
        }
    }
    func fetchHomeFeed(onCompletion: @escaping(HomeDatasource?,Error?) -> () ){
        
        //start our json fetch
        
        let request: APIRequest<HomeDatasource,JSONError> = tron.request("/twitter/home")
        
        request.perform(withSuccess: {(homeDatasource) in
            
            onCompletion(homeDatasource,nil)
            
        }, failure: {(err) in
            onCompletion(nil,err)
            print("Something went wrong",err)
            
        })
    }
    
    
    
    
    
    
}

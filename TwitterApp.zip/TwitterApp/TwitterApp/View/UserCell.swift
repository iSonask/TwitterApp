//
//  UserCell.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 05/05/17.
//
//

import LBTAComponents

class UserCell: DatasourceCell{
    
    override var datasourceItem: Any?{
        didSet{
            //            nameLabel.text = datasourceItem as? String
            guard let user = datasourceItem as? User  else {
                return
            }
            nameLabel.text = user.name
            usernameLabel.text = user.username
            bioTextView.text = user.biotext
            profileimageVIew.loadImage(urlString: user.profileimageURL)
        }
    }
    
    let nameLabel: UILabel = {
        let lbl = UILabel()
        lbl.text = "Robert Downey Jr."
        lbl.font = UIFont.boldSystemFont(ofSize: 16)
        return lbl
    }()
    
    let profileimageVIew: CachedImageView = {
        let img = CachedImageView()
//        img.image = #imageLiteral(resourceName: "downey")
        img.layer.cornerRadius = 5
        img.layer.masksToBounds = true
        return img
    }()
    
    let usernameLabel: UILabel = {
        let lbl = UILabel()
        lbl.text = "@RBJr"
        lbl.textColor = .gray
        lbl.font = UIFont.systemFont(ofSize: 14)
        return lbl
    }()
    
    let bioTextView: UITextView = {
        let textview = UITextView()
        textview.text = "Hey this is IRON MAN , AKA Tony Stark , CEO of Stark Industries , kudos...!"
        textview.font = UIFont.systemFont(ofSize: 15)
        textview.isUserInteractionEnabled = true
        return textview
    }()
    
    let followButton: UIButton = {
        let btn = UIButton(type: .system)
        let color = UIColor(r: 61, g: 167, b: 244, a: 1.0)
        btn.layer.borderColor = color.cgColor
        btn.tintColor = color
        btn.layer.cornerRadius = 5
        btn.layer.borderWidth = 1
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        btn.setTitle("Follow", for: .normal)
        btn.setImage(#imageLiteral(resourceName: "add"), for: .normal)
        btn.imageView?.contentMode = .scaleAspectFit
        btn.imageEdgeInsets = UIEdgeInsets(top: 0, left: -8, bottom: 0, right: 0)
        btn.setTitleColor(color, for: .normal)
        return btn
    }()
    override func setupViews() {
        super.setupViews()
        
        separatorLineView.isHidden = false
        separatorLineView.backgroundColor = .lightGray
        backgroundColor = .white
        addSubview(profileimageVIew)
        addSubview(nameLabel)
        addSubview(usernameLabel)
        addSubview(bioTextView)
        addSubview(followButton)
        
        profileimageVIew.anchor(self.topAnchor, left: self.leftAnchor, bottom: nil, right: nil, topConstant: 12, leftConstant: 12, bottomConstant: 0, rightConstant: 0, widthConstant: 50, heightConstant: 50)
        
        nameLabel.anchor(profileimageVIew.topAnchor, left: profileimageVIew.rightAnchor, bottom: nil, right: followButton.leftAnchor, topConstant: 0, leftConstant: 4, bottomConstant: 0, rightConstant: 12, widthConstant: 0, heightConstant: 20)
        
        usernameLabel.anchor(nameLabel.bottomAnchor, left: nameLabel.leftAnchor, bottom: nil, right: nameLabel.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 25)
        
        bioTextView.anchor(usernameLabel.bottomAnchor, left: usernameLabel.leftAnchor, bottom: self.bottomAnchor, right: self.rightAnchor, topConstant: -4, leftConstant: -4, bottomConstant: 5, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        
        followButton.anchor(self.topAnchor, left: nil, bottom: nil, right: self.rightAnchor, topConstant: 12, leftConstant: 0, bottomConstant: 0, rightConstant: 12, widthConstant: 120, heightConstant: 34)
    }
}

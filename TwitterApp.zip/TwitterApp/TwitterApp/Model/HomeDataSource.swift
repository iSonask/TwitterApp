//
//  HomeDataSource.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 05/05/17.
//
//

import LBTAComponents
import TRON
import SwiftyJSON

extension Collection where Iterator.Element == JSON{
    func decode<T: JSONDecodable>() throws -> [T] {
        return try map{try T(json: $0)}
        
    }
}

class HomeDatasource: Datasource,JSONDecodable {
    //    let words = ["one","two","three"]
    
    let users: [User]
    let tweets: [Tweet]
    
    required init(json: JSON) throws {
        
        guard let userJsonarray = json["users"].array , let tweetJsonArray = json["tweets"].array else {
            throw NSError(domain: "hey", code: 1, userInfo: [NSLocalizedDescriptionKey: "uSer not valid in JSON"])
        }
        self.users = try userJsonarray.decode()
        self.tweets = try tweetJsonArray.decode()
    }
    
    
    override func numberOfSections() -> Int {
        return 2
    }
    
    override func item(_ indexPath: IndexPath) -> Any? {
        if indexPath.section == 1{
            return tweets[indexPath.item]
        } else {
            return users[indexPath.item]
        }
    }
    override func numberOfItems(_ section: Int) -> Int {
        if section == 1{
            return tweets.count
        }
        return users.count
    }
    override func cellClasses() -> [DatasourceCell.Type] {
        return [UserCell.self,TweetCell.self]
    }
    override func headerClasses() -> [DatasourceCell.Type]? {
        return [userHeader.self]
    }
    override func footerClasses() -> [DatasourceCell.Type]? {
        return [userFooter.self]
    }
}

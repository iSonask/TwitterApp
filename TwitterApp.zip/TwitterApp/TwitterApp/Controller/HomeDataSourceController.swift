//
//  HomeDataSourceController.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 05/05/17.
//
//

import LBTAComponents
import TRON
import SwiftyJSON

class HomeDatasourceController: DatasourceController {
    let errorMessageLabel: UILabel = {
        let lbl = UILabel()
        lbl.text = "Applogies something went wrong. Please try again later..."
        lbl.textAlignment = .center
        lbl.numberOfLines = 0
        lbl.isHidden = true
        return lbl
    }()
    override func viewDidLoad(){
        super.viewDidLoad()
        collectionView?.backgroundColor = UIColor(r: 232, g: 236, b: 241)
        setupNavigationBarItems()
        view.addSubview(errorMessageLabel)
        errorMessageLabel.fillSuperview()
        Service.sharedInstance.fetchHomeFeed(onCompletion: {(homeDatasource, error )in
            if error != nil {
                self.errorMessageLabel.isHidden = false
                print("error fetching data source")
                if let apiError = error as? APIError<Service.JSONError>{
                    if apiError.response?.statusCode != 200{
                        self.errorMessageLabel.text = "Status code was not 200"
                    }
                }
            }
            self.datasource = homeDatasource
        })
    }
    
    override func willTransition(to newCollection: UITraitCollection, with coordinator: UIViewControllerTransitionCoordinator) {
        collectionViewLayout.invalidateLayout()
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0{
            
            guard let user =  self.datasource?.item(indexPath) as? User else {
                return .zero
            }  //estimation of height base on text
            let estimatedHeight = estimatedHeightForText(user.biotext)
            
            return CGSize(width: view.frame.width , height: estimatedHeight + 66)
            
        } else if indexPath.section == 1{
            guard let tweet = datasource?.item(indexPath) as? Tweet else {
                return .zero
            }
            let estimatedHeight = estimatedHeightForText(tweet.message)
            return CGSize(width: view.frame.width , height: estimatedHeight + 75)
        }
        
        return CGSize(width: view.frame.width, height: 200)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 1{
            return .zero
        }
        return CGSize(width: view.frame.width, height: 50)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if section == 1{
            return .zero
        }
        return CGSize(width: view.frame.width, height: 64)
    }
    private func estimatedHeightForText(_ text: String) -> CGFloat {
        
        let approximatewidhofBioTextview = view.frame.width - 12 - 50 - 13
        let size = CGSize(width: approximatewidhofBioTextview, height: 1000)
        let attribute = [NSFontAttributeName: UIFont.systemFont(ofSize: 15)]
        let estimatedFrame = NSString(string: text).boundingRect(with: size, options:.usesLineFragmentOrigin , attributes: attribute, context: nil)
        return estimatedFrame.height
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
























//
//  TweetCell.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 06/05/17.
//
//

import LBTAComponents

class TweetCell: DatasourceCell {
    override var datasourceItem: Any?{
        didSet{
            guard let tweet = datasourceItem as? Tweet  else {
                return
            }
            let attributedText = NSMutableAttributedString(string: tweet.user.name, attributes: [NSFontAttributeName: UIFont.boldSystemFont(ofSize: 16)])
            let usernameString = "  \(tweet.user.username)\n"
            attributedText.append(NSAttributedString(string:usernameString , attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 15),NSForegroundColorAttributeName:UIColor.gray]))
            
            let range = NSMakeRange(0, attributedText.string.characters.count)
            
            let style = NSMutableParagraphStyle()
            
            style.lineSpacing = 5
            
            attributedText.addAttribute(NSParagraphStyleAttributeName, value: style, range: range)
            
            attributedText.append(NSAttributedString(string: tweet.message, attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 15)]))
            
            profileimageVIew.loadImage(urlString: tweet.user.profileimageURL)
            textView.attributedText = attributedText
        }
    }//https://api.letsbuildthatapp.com/twitter/home
    let textView: UITextView = {
        let tv = UITextView()
        tv.text = "SOme sample text"
        tv.backgroundColor = .clear
        return tv
    }()
    
    let profileimageVIew: CachedImageView = {
        let img = CachedImageView()
//        img.image = #imageLiteral(resourceName: "downey")
        img.layer.cornerRadius = 5
        img.layer.masksToBounds = true
        return img
    }()
    
    
    let replyButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "reply"), for: .normal)
        btn.tintColor = UIColor(r: 129, g: 129, b: 129)
        btn.addTarget(self, action: #selector(replyMessageTapped), for: .touchUpInside)
        return btn
    }()
    
    let retweetButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "retweet"), for: .normal)
        btn.tintColor = UIColor(r: 129, g: 129, b: 129)
        btn.addTarget(self, action: #selector(retweetTapped), for: .touchUpInside)
        return btn
    }()
    let likeButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "favourite"), for: .normal)
        btn.tintColor = UIColor(r: 129, g: 129, b: 129)
        btn.addTarget(self, action: #selector(LikeTapped), for: .touchUpInside)
        return btn
    }()
    let directMessageButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "message"), for: .normal)
        btn.tintColor = UIColor(r: 129, g: 129, b: 129)
        btn.addTarget(self, action: #selector(directMessageTapped), for: .touchUpInside)
        return btn
    }()
    func directMessageTapped(){
        print("directMessageTapped")
    }
    func replyMessageTapped(){
        print("directMessageTapped")
    }
    func retweetTapped(){
        print("directMessageTapped")
    }
    func LikeTapped(){
        print("directMessageTapped")
    }
    override func setupViews() {
        super.setupViews()
        separatorLineView.isHidden = false
        separatorLineView.backgroundColor = UIColor(r: 230, g: 230, b: 230)
        
        backgroundColor = .white
        addSubview(profileimageVIew)
        addSubview(textView)
        addSubview(replyButton)
        
        profileimageVIew.anchor(self.topAnchor, left: self.leftAnchor, bottom: nil, right: nil, topConstant: 12, leftConstant: 12, bottomConstant: 0, rightConstant: 0, widthConstant: 50, heightConstant: 50)
        textView.anchor(self.topAnchor, left: profileimageVIew.rightAnchor, bottom: self.bottomAnchor, right: self.rightAnchor, topConstant: 5, leftConstant: 5, bottomConstant: 5, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        

        setupBottomButton()
    }
    fileprivate func setupBottomButton(){
        let replyButtonContainerView = UIView()
        let retweetButtonContainerView = UIView()
        let likeButtonContainerView = UIView()
        let directMessageButtonContainerView = UIView()
        let buttonStackVIew = UIStackView(arrangedSubviews: [replyButtonContainerView,retweetButtonContainerView,likeButtonContainerView,directMessageButtonContainerView])
        
        buttonStackVIew.axis = .horizontal
        buttonStackVIew.distribution = .fillEqually
        addSubview(buttonStackVIew)
        buttonStackVIew.anchor(nil, left: textView.leftAnchor, bottom: self.bottomAnchor, right: self.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 5, rightConstant: 0, widthConstant: 0, heightConstant: 20)
        
        addSubview(replyButton)
        addSubview(retweetButton)
        addSubview(likeButton)
        addSubview(directMessageButton)
        
        replyButton.anchor(replyButtonContainerView.topAnchor, left: replyButtonContainerView.leftAnchor, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 20, heightConstant: 20)
        retweetButton.anchor(retweetButtonContainerView.topAnchor, left: retweetButtonContainerView.leftAnchor, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 20, heightConstant: 20)
        likeButton.anchor(likeButtonContainerView.topAnchor, left: likeButtonContainerView.leftAnchor, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 20, heightConstant: 20)
        directMessageButton.anchor(directMessageButtonContainerView.topAnchor, left: directMessageButtonContainerView.leftAnchor, bottom: nil, right: nil, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 20, heightConstant: 20)
        
    }
    
    
    
    
    
    
}

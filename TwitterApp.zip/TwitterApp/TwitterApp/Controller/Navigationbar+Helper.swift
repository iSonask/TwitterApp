//
//  Navigationbar+Helper.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 05/05/17.
//
//

import Foundation
import UIKit

extension HomeDatasourceController{
    func setupNavigationBarItems() {
        let titleimageview = UIImageView(image: #imageLiteral(resourceName: "twitter"))
        titleimageview.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        titleimageview.contentMode = .scaleAspectFit
        navigationItem.titleView = titleimageview
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addClicked))
        
        navigationItem.rightBarButtonItems = [UIBarButtonItem(barButtonSystemItem: .compose, target: self, action: #selector(searchClicked)),UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(saveClicked))]
        
        navigationController?.navigationBar.backgroundColor = .white
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        let navBarSeparatorView = UIView()
        navBarSeparatorView.backgroundColor = UIColor(r: 230, g: 230, b: 230)
        view.addSubview(navBarSeparatorView)
        navigationController?.navigationBar.tintColor = UIColor(r: 61, g: 167, b: 244, a: 1.0)
        navBarSeparatorView.anchor(view.topAnchor, left: view.leftAnchor, bottom: nil, right: view.rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 0.5)
    }
    
    func addClicked(_ sender: UIButton)  {
        print("addTapped")
    }
    func searchClicked(_ sender: UIButton)  {
        print("searchClicked")
    }
    func saveClicked(_ sender: UIButton)  {
        print("saveClicked")
    }
    
}

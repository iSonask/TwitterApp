//
//  Cells.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 05/05/17.
//
//

import LBTAComponents

class userHeader: DatasourceCell {
    
    let textLabel: UILabel = {
        let lbl = UILabel()
        lbl.text = "Who to Follow"
        lbl.font = UIFont.boldSystemFont(ofSize: 16)
        return lbl
    }()
    override func setupViews() {
        super.setupViews()
        separatorLineView.isHidden = false
        backgroundColor = .white
        addSubview(textLabel)
        textLabel.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 0, leftConstant: 10, bottomConstant: 0, rightConstant: 0, widthConstant: 0, heightConstant: 25)
//        textLabel.fillSuperview()
        
    }
}
class userFooter: DatasourceCell {
    
    let textLabel: UILabel = {
        let lbl = UILabel()
        lbl.text = "Show More"
        let color = UIColor(r: 61, g: 167, b: 244, a: 1.0)
        lbl.textColor = color
        lbl.font = UIFont.boldSystemFont(ofSize: 16)
        return lbl
    }()
    
    override func setupViews() {
        super.setupViews()
        let whiteBackgroundView = UIView()
        whiteBackgroundView.backgroundColor = .white
        addSubview(whiteBackgroundView)
        whiteBackgroundView.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 0, leftConstant: 0, bottomConstant: 14, rightConstant: 0, widthConstant: 0, heightConstant: 0)
        addSubview(textLabel)
        textLabel.anchor(topAnchor, left: leftAnchor, bottom: bottomAnchor, right: rightAnchor, topConstant: 0, leftConstant: 10, bottomConstant: 14, rightConstant: 0, widthConstant: 0, heightConstant: 25)
    }
}



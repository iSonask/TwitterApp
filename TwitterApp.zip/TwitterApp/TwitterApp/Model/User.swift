//
//  User.swift
//  TwitterApp
//
//  Created by FARHAN IT SOLUTION on 05/05/17.
//
//

import Foundation
import UIKit
import SwiftyJSON
import TRON

struct User: JSONDecodable {
    
    let name: String
    let username: String
    let biotext: String
    let profileImage: UIImage
    let profileimageURL: String
    
    init(json: JSON) {
        self.name = json["name"].stringValue
        self.username = json["username"].stringValue
        self.biotext = json["bio"].stringValue
        self.profileimageURL = json["profileImageUrl"].stringValue
        self.profileImage = UIImage()
        
    }
}











